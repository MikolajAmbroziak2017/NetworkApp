package com.example.demo;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public class Service {

    public ArrayList<String> messageList =new ArrayList<String>();
}

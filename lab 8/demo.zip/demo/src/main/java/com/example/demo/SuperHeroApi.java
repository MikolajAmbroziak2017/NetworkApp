package com.example.demo;

import net.bytebuddy.implementation.bind.annotation.Super;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.example.demo.Skill.FIRE_BALL;

@RestController
public class SuperHeroApi {
    @GetMapping("/creat")
    public void create(){
        SuperHero superHero= new SuperHero();
        superHero.setSkill(FIRE_BALL);
        superHero.setName("Pawełek");
    }
}

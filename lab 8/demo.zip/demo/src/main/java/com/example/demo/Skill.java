package com.example.demo;

public enum Skill {
    WILD_WIRE,FIRE_BALL,IMMORTABLE,INVISABLE
}

package app;

import java.util.Map;

public interface Updatable {
    void update(Map<String, String> paramsToUpdate);
}
